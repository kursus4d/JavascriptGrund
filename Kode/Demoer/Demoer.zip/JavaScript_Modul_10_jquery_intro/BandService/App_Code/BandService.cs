﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

// NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service" in code, svc and config file together.
public class BandService : IBandService
{

    public string GetBandMembers()
    {
      
        return "wango tango";
    }

    //public List<BandMember> GetBandMembers()
    //{
    //    List<BandMember> bs = new List<BandMember>();
    //    bs.Add(new BandMember() { FirstName= "Ozzy", LastName= "Osbourne", Instrument="Vocal" });
    //    bs.Add(new BandMember() { FirstName = "Tony", LastName = "Iommi", Instrument = "Guitar" });
    //    bs.Add(new BandMember() { FirstName = "Geezer", LastName = "Butler", Instrument = "Bass" });
    //    bs.Add(new BandMember() { FirstName = "Bill", LastName = "Ward", Instrument = "Drums" });

    //    return bs;
    //}
	
}
