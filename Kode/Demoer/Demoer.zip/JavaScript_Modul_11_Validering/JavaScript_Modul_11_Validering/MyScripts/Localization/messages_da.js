$.extend($.validator.messages, {
    required: "Feltet skal udfyldes",
    email: "Angiv en gyldig e-mail-adresse",
    maxlength: jQuery.validator.format("Feltet skal være på højest {0} karakterer."),
    minlength: jQuery.validator.format("Feltet skal være på mindst {0} karakterer")
});