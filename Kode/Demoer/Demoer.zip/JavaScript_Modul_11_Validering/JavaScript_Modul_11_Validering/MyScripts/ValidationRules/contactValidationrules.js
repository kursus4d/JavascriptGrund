$(document).ready(function () {
    $("#contactForm").validate({
        rules: {
            txtFirstName: {
                required: true,
                minlength: 2
            },
            txtLastName: {
                required: true,
                minlength: 2
            },
            txtEmail: {
                required: true,
                email: true
            }
        },
        messages: {
            txtFirstName: {
                required: "Du skal udfylde feltet",
                minlength: "Fornavnet skal være på mindst 2 karakterer"
            },
            txtLastName: {
                required: "Du skal udfylde feltet",
                minlength: "Efternavnet skal være på mindst 2 karakterer"
            },
            txtEmail: {
                required: "Du skal angive en gyldig e-mail-adresse",
                email: "Den angivne e-mail-adresse er ikke en gyldig adresse"

            }
        }
    });
});


















//http://stackoverflow.com/questions/2457032/jquery-validation-change-default-error-message
