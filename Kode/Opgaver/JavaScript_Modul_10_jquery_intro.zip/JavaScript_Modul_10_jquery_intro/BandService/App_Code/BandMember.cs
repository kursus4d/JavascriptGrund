﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for BandMember
/// </summary>

public class BandMember
{
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public string Instrument { get; set; }
}